import setuptools

setuptools.setup(
    name="convertator_v1",
    version="1.1",
    author="Timurius",
    description='package for convert str and files to Json format',
    url='http://github.com/example.py',
    packages=['convertorjson'],
    install_requires=['json'],
)