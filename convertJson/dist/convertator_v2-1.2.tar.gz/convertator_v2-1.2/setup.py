import setuptools

setuptools.setup(
    name="convertator_v2",
    version="1.2",
    author="Timurius",
    description='package for convert str and files to Json format',
    url='https://github.com/redbuzzz/secondCourse/tree/main/convertJson',
    packages=['convertorjson'],
)